﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class otherMovement : MonoBehaviour
{
    
    Rigidbody2D rb2d;
    //RaycastHit hitInfo;

    public float speed = 1000f;
    public float jumpHeight = 1000f;
    public bool canJump = true;
    public int correctAnswers = 0;
    public AudioSource tickSource;
    private Transform groundCheck;


    Vector3 startingPosition; // If we hit a spike we will teleport player to starting position.

    void Awake()
    {
        // Setting up references.
        //   groundCheck = transform.Find("groundCheck");
    }

    void Start()
    {
        tickSource = GetComponent<AudioSource>();
        rb2d = GetComponent<Rigidbody2D>(); // Get the rigidbody component added to the object and store it in rb2d
        startingPosition = transform.position;
    }

    void Update()
    {
        if (Input.GetKey(KeyCode.LeftArrow) || Input.GetKey(KeyCode.RightArrow) || Input.GetKey(KeyCode.UpArrow))
        {
            var input = Input.GetAxis("Horizontal"); // This will give us left and right movement (from -1 to 1). 
            var movement = input * speed;

            rb2d.velocity = new Vector3(movement, rb2d.velocity.y, 0);
            //canJump = Physics2D.Linecast(transform.position, groundCheck.position, 1 << LayerMask.NameToLayer("Ground"));
            if (Input.GetKeyDown(KeyCode.UpArrow) && (canJump == true))
            {
                tickSource.Play();
                rb2d.AddForce(new Vector3(0, jumpHeight, 0));
                //canJump = false;
            }
        }
    }

    void OnTriggerEnter2D(Collider2D col) // col is the trigger object we collided with
    {
        if (col.tag == "Answer")
        {
            correctAnswers++;
            Destroy(col.gameObject); // remove the coin
        }
        else if (col.tag == "Water")
        {
            // Death? Reload Scene? Teleport to start:
            transform.position = startingPosition;
        }
        else if (col.tag == "Spike")
        {
            // Death? Reload Scene? Teleport to start:
            transform.position = startingPosition;
        }
        else if (col.tag == "End")
        {
            // Load next level? Heres how you get this level's scene number, add 1 to it and load that scene:
            // SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex + 1);
        }
    }
}

