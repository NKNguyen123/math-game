﻿using UnityEngine;
using System.Collections;

public class Player2Movement : MonoBehaviour

{

    public AudioSource tickSource;
    void Start() => tickSource = GetComponent<AudioSource>();
    void Update()
    {
        if (Input.GetKey(KeyCode.A))
        {
            Vector3 position = this.transform.position;
            if (position.x > -31)
            {
                position.x--;
                this.transform.position = position;
            }
        }
        if (Input.GetKey(KeyCode.D))
        {
            Vector3 position = this.transform.position;
            if (position.x < 31)
            {
                position.x++;
                this.transform.position = position;
            }
        }
        if (Input.GetKeyDown(KeyCode.W))
        {
            Vector3 position = this.transform.position;
            if (position.y < 2)
            {
                position.y += 10;
                this.transform.position = position;
                tickSource.Play();
            }
        }
        //if (Input.GetKey(KeyCode.DownArrow))
        {
            //Vector3 position = this.transform.position;
            //position.y--;
            //this.transform.position = position;
        }//
    }
}